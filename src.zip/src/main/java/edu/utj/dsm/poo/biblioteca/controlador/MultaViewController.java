// CONTRERAS MARTINEZ BRYAN DANIEL
package edu.utj.dsm.poo.biblioteca.controlador;

import edu.utj.dsm.poo.biblioteca.modelo.Multa;
import edu.utj.dsm.poo.biblioteca.modelo.Prestamo;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class MultaViewController implements Initializable {

    @FXML private TextField txtId;
    @FXML private TextField txtMonto;
    @FXML private TextField txtIdPrestamo;
    @FXML private CheckBox chkPagada;

    @FXML private Button btnNuevo;
    @FXML private Button btnGuardar;
    @FXML private Button btnEliminar;
    @FXML private Button btnLimpiar;

    @FXML private TableView<Multa> tblMultas;
    @FXML private TableColumn<Multa, Integer> colId;
    @FXML private TableColumn<Multa, Double> colMonto;
    @FXML private TableColumn<Multa, String> colEstado;
    @FXML private TableColumn<Multa, String> colPrestamo;

    private final ObservableList<Multa> listaMultas = FXCollections.observableArrayList();
    private int siguienteId = 1;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colMonto.setCellValueFactory(new PropertyValueFactory<>("monto"));
        
        // Mapeo para mostrar "Pagada" o "Pendiente"
        colEstado.setCellValueFactory(cellData -> {
            return new SimpleStringProperty(cellData.getValue().isPagada() ? "Pagada" : "Pendiente");
        });
        
        // Mapeo para extraer el ID del préstamo
        colPrestamo.setCellValueFactory(cellData -> {
            Prestamo p = cellData.getValue().getPrestamo();
            return new SimpleStringProperty(p != null ? "Préstamo #" + p.getId() : "Sin asignar");
        });

        tblMultas.setItems(listaMultas);

        tblMultas.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                txtId.setText(String.valueOf(newSel.getId()));
                txtMonto.setText(String.valueOf(newSel.getMonto()));
                txtIdPrestamo.setText(String.valueOf(newSel.getPrestamo().getId()));
                chkPagada.setSelected(newSel.isPagada());
            }
        });
    }

    @FXML
    private void accionNuevo(ActionEvent event) {
        accionLimpiar(event);
    }

    @FXML
    private void accionGuardar(ActionEvent event) {
        String textoMonto = txtMonto.getText().trim();
        String textoPrestamo = txtIdPrestamo.getText().trim();

        if (textoMonto.isEmpty() || textoPrestamo.isEmpty()) {
            mostrarAlerta("Validación", "Campos incompletos", "Debes ingresar el monto y el ID del préstamo.");
            return;
        }

        double monto;
        int idPrestamo;
        try {
            monto = Double.parseDouble(textoMonto);
            idPrestamo = Integer.parseInt(textoPrestamo);
        } catch (NumberFormatException e) {
            mostrarAlerta("Error", "Formato inválido", "El monto debe ser numérico y el ID del préstamo un número entero.");
            return;
        }

        // Creamos un préstamo simulado solo con el ID para cumplir con tu modelo
        Prestamo prestamoTemp = new Prestamo();
        prestamoTemp.setId(idPrestamo);

        if (txtId.getText().isEmpty()) {
            Multa multa = new Multa(siguienteId++, monto, prestamoTemp);
            multa.setPagada(chkPagada.isSelected());
            
            listaMultas.add(multa);
            mostrarAlerta("Éxito", "Multa registrada", "La multa se ha guardado correctamente.");
        } else {
            Multa multa = tblMultas.getSelectionModel().getSelectedItem();
            if (multa != null) {
                multa.setMonto(monto);
                multa.setPrestamo(prestamoTemp);
                multa.setPagada(chkPagada.isSelected());
                
                tblMultas.refresh();
                mostrarAlerta("Éxito", "Multa actualizada", "Los datos de la multa han sido modificados.");
            }
        }
        accionLimpiar(event);
    }

    @FXML
    private void accionEliminar(ActionEvent event) {
        Multa multa = tblMultas.getSelectionModel().getSelectedItem();
        if (multa != null) {
            listaMultas.remove(multa);
            accionLimpiar(event);
            mostrarAlerta("Éxito", "Multa eliminada", "El registro ha sido borrado.");
        } else {
            mostrarAlerta("Aviso", "Sin selección", "Selecciona una multa para eliminar.");
        }
    }

    @FXML
    private void accionLimpiar(ActionEvent event) {
        txtId.clear();
        txtMonto.clear();
        txtIdPrestamo.clear();
        chkPagada.setSelected(false);
        tblMultas.getSelectionModel().clearSelection();
    }

    private void mostrarAlerta(String titulo, String cabecera, String contenido) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(cabecera);
        alert.setContentText(contenido);
        alert.showAndWait();
    }
}