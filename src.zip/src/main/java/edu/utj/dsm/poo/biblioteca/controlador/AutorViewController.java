// CONTRERAS MARTINEZ BRYAN DANIEL
package edu.utj.dsm.poo.biblioteca.controlador;

import edu.utj.dsm.poo.biblioteca.modelo.Autor;
import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class AutorViewController implements Initializable {

    @FXML private TextField txtId;
    @FXML private TextField txtNombre;
    @FXML private TextField txtPrimerApellido;
    @FXML private TextField txtNacionalidad;
    @FXML private TextField txtSeudonimo;
    @FXML private ImageView imgFoto;
    @FXML private Button btnSeleccionarImagen;

    @FXML private Button btnNuevo;
    @FXML private Button btnGuardar;
    @FXML private Button btnEditar;
    @FXML private Button btnEliminar;
    @FXML private Button btnLimpiar;

    @FXML private TableView<Autor> tblAutores;
    @FXML private TableColumn<Autor, Integer> colId;
    @FXML private TableColumn<Autor, String> colNombre;
    @FXML private TableColumn<Autor, String> colApellido;
    @FXML private TableColumn<Autor, String> colNacionalidad;
    @FXML private TableColumn<Autor, String> colSeudonimo;

    private final ObservableList<Autor> listaAutores = FXCollections.observableArrayList();
    private int siguienteId = 1;
    private String rutaImagenSeleccionada = "";

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colApellido.setCellValueFactory(new PropertyValueFactory<>("primerApellido"));
        colNacionalidad.setCellValueFactory(new PropertyValueFactory<>("nacionalidad"));
        colSeudonimo.setCellValueFactory(new PropertyValueFactory<>("seudonimo"));

        tblAutores.setItems(listaAutores);

        tblAutores.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                txtId.setText(String.valueOf(newSel.getId()));
                txtNombre.setText(newSel.getNombre());
                txtPrimerApellido.setText(newSel.getPrimerApellido());
                txtNacionalidad.setText(newSel.getNacionalidad());
                txtSeudonimo.setText(newSel.getSeudonimo() != null ? newSel.getSeudonimo() : "");
                rutaImagenSeleccionada = newSel.getRutaImagen();
                cargarImagenVistaPrevia(rutaImagenSeleccionada);
            }
        });
    }

    @FXML
    private void accionSeleccionarImagen(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar Fotografía");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Archivos de Imagen", "*.png", "*.jpg", "*.jpeg"));
        Stage stage = (Stage) btnSeleccionarImagen.getScene().getWindow();
        File archivo = fileChooser.showOpenDialog(stage);
        if (archivo != null) {
            rutaImagenSeleccionada = archivo.toURI().toString();
            cargarImagenVistaPrevia(rutaImagenSeleccionada);
        }
    }

    private void cargarImagenVistaPrevia(String ruta) {
        if (ruta != null && !ruta.isEmpty()) {
            try {
                imgFoto.setImage(new Image(ruta));
            } catch (Exception e) {
                imgFoto.setImage(null);
            }
        } else {
            imgFoto.setImage(null);
        }
    }

    @FXML
    private void accionNuevo(ActionEvent event) {
        accionLimpiar(event);
    }

    @FXML
    private void accionGuardar(ActionEvent event) {
        String nombre = txtNombre.getText().trim();
        String apellido = txtPrimerApellido.getText().trim();
        String nacionalidad = txtNacionalidad.getText().trim();
        String seudonimo = txtSeudonimo.getText().trim();

        if (nombre.isEmpty() || apellido.isEmpty() || nacionalidad.isEmpty()) {
            mostrarAlerta("Validación", "Campos incompletos", "Nombre, Apellido y Nacionalidad son obligatorios.");
            return;
        }

        if (txtId.getText().isEmpty()) {
            Autor autor = new Autor();
            autor.setId(siguienteId++);
            autor.setNombre(nombre);
            autor.setPrimerApellido(apellido);
            autor.setNacionalidad(nacionalidad);
            autor.setSeudonimo(seudonimo);
            autor.setRutaImagen(rutaImagenSeleccionada);

            listaAutores.add(autor);
            mostrarAlerta("Éxito", "Autor registrado", "El autor ha sido guardado correctamente.");
        } else {
            Autor autor = tblAutores.getSelectionModel().getSelectedItem();
            if (autor != null) {
                autor.setNombre(nombre);
                autor.setPrimerApellido(apellido);
                autor.setNacionalidad(nacionalidad);
                autor.setSeudonimo(seudonimo);
                autor.setRutaImagen(rutaImagenSeleccionada);

                tblAutores.refresh();
                mostrarAlerta("Éxito", "Autor actualizado", "Los datos del autor han sido modificados.");
            }
        }
        accionLimpiar(event);
    }

    @FXML
    private void accionEditar(ActionEvent event) {
        Autor autor = tblAutores.getSelectionModel().getSelectedItem();
        if (autor == null) {
            mostrarAlerta("Aviso", "Sin selección", "Selecciona un autor de la tabla para editar.");
        } else {
            txtNombre.requestFocus();
        }
    }

    @FXML
    private void accionEliminar(ActionEvent event) {
        Autor autor = tblAutores.getSelectionModel().getSelectedItem();
        if (autor != null) {
            listaAutores.remove(autor);
            accionLimpiar(event);
            mostrarAlerta("Éxito", "Autor eliminado", "El registro ha sido borrado.");
        } else {
            mostrarAlerta("Aviso", "Sin selección", "Selecciona un autor para eliminar.");
        }
    }

    @FXML
    private void accionLimpiar(ActionEvent event) {
        txtId.clear();
        txtNombre.clear();
        txtPrimerApellido.clear();
        txtNacionalidad.clear();
        txtSeudonimo.clear();
        tblAutores.getSelectionModel().clearSelection();
        imgFoto.setImage(null);
        rutaImagenSeleccionada = "";
    }

    private void mostrarAlerta(String titulo, String cabecera, String contenido) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(cabecera);
        alert.setContentText(contenido);
        alert.showAndWait();
    }
}