// CONTRERAS MARTINEZ BRYAN DANIEL
package edu.utj.dsm.poo.biblioteca.controlador;

import edu.utj.dsm.poo.biblioteca.modelo.Autor;
import edu.utj.dsm.poo.biblioteca.modelo.Editorial;
import edu.utj.dsm.poo.biblioteca.modelo.Libro;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class LibroViewController implements Initializable {

    @FXML private TextField txtId;
    @FXML private TextField txtTitulo;
    @FXML private TextField txtIsbn;
    @FXML private TextField txtPaginas;
    @FXML private TextField txtAutor;
    @FXML private TextField txtEditorial;

    @FXML private Button btnNuevo;
    @FXML private Button btnGuardar;
    @FXML private Button btnEditar;
    @FXML private Button btnEliminar;
    @FXML private Button btnLimpiar;

    @FXML private TableView<Libro> tblLibros;
    @FXML private TableColumn<Libro, Integer> colId;
    @FXML private TableColumn<Libro, String> colTitulo;
    @FXML private TableColumn<Libro, String> colIsbn;
    @FXML private TableColumn<Libro, Integer> colPaginas;
    @FXML private TableColumn<Libro, Object> colAutor;
    @FXML private TableColumn<Libro, Object> colEditorial;

    private final ObservableList<Libro> listaLibros = FXCollections.observableArrayList();
    private int siguienteId = 1;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Enlazamos las columnas con los atributos de Libro y Material
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colTitulo.setCellValueFactory(new PropertyValueFactory<>("titulo"));
        colIsbn.setCellValueFactory(new PropertyValueFactory<>("isbn"));
        colPaginas.setCellValueFactory(new PropertyValueFactory<>("numeroPaginas"));
        colAutor.setCellValueFactory(new PropertyValueFactory<>("autor"));
        colEditorial.setCellValueFactory(new PropertyValueFactory<>("editorial"));

        tblLibros.setItems(listaLibros);

        tblLibros.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                txtId.setText(String.valueOf(newSel.getId()));
                txtTitulo.setText(newSel.getTitulo());
                txtIsbn.setText(newSel.getIsbn());
                txtPaginas.setText(String.valueOf(newSel.getNumeroPaginas()));
                
                // Extraemos el nombre del objeto Autor y Editorial para mostrarlo en el texto
                // (Asumo que Autor y Editorial tienen el método getNombre())
                txtAutor.setText(newSel.getAutor() != null ? newSel.getAutor().getNombre() : "");
                txtEditorial.setText(newSel.getEditorial() != null ? newSel.getEditorial().getNombre() : "");
            }
        });
    }

    @FXML
    private void accionNuevo(ActionEvent event) {
        accionLimpiar(event);
    }

    @FXML
    private void accionGuardar(ActionEvent event) {
        String titulo = txtTitulo.getText().trim();
        String isbn = txtIsbn.getText().trim();
        String textoPaginas = txtPaginas.getText().trim();
        String nombreAutor = txtAutor.getText().trim();
        String nombreEditorial = txtEditorial.getText().trim();

        if (titulo.isEmpty() || isbn.isEmpty()) {
            mostrarAlerta("Validación", "Campos incompletos", "El título y el ISBN son obligatorios.");
            return;
        }

        int paginas = 0;
        try {
            if (!textoPaginas.isEmpty()) paginas = Integer.parseInt(textoPaginas);
        } catch (NumberFormatException e) {
            mostrarAlerta("Error", "Formato inválido", "El número de páginas debe ser numérico.");
            return;
        }

        if (txtId.getText().isEmpty()) {
            Libro libro = new Libro();
            libro.setId(siguienteId++); // Viene de la clase padre Material
            libro.setTitulo(titulo);    // Viene de la clase padre Material
            libro.setIsbn(isbn);
            libro.setNumeroPaginas(paginas);
            
            // Creamos los objetos Autor y Editorial a partir de lo que escribió el usuario
            Autor autorObj = new Autor();
            autorObj.setNombre(nombreAutor);
            libro.setAutor(autorObj);
            
            Editorial editorialObj = new Editorial();
            editorialObj.setNombre(nombreEditorial);
            libro.setEditorial(editorialObj);
            
            listaLibros.add(libro);
            mostrarAlerta("Éxito", "Registro creado", "Libro registrado correctamente.");
        } else {
            Libro libro = tblLibros.getSelectionModel().getSelectedItem();
            if (libro != null) {
                libro.setTitulo(titulo);
                libro.setIsbn(isbn);
                libro.setNumeroPaginas(paginas);
                
                libro.getAutor().setNombre(nombreAutor);
                libro.getEditorial().setNombre(nombreEditorial);
                
                tblLibros.refresh();
                mostrarAlerta("Éxito", "Registro actualizado", "Libro modificado correctamente.");
            }
        }
        accionLimpiar(event);
    }

    @FXML
    private void accionEditar(ActionEvent event) {
        Libro libro = tblLibros.getSelectionModel().getSelectedItem();
        if (libro == null) {
            mostrarAlerta("Aviso", "Sin selección", "Selecciona un libro de la tabla.");
        } else {
            txtTitulo.requestFocus();
        }
    }

    @FXML
    private void accionEliminar(ActionEvent event) {
        Libro libro = tblLibros.getSelectionModel().getSelectedItem();
        if (libro != null) {
            listaLibros.remove(libro);
            accionLimpiar(event);
            mostrarAlerta("Éxito", "Eliminado", "Registro eliminado de la lista.");
        } else {
            mostrarAlerta("Aviso", "Sin selección", "Selecciona un libro para eliminar.");
        }
    }

    @FXML
    private void accionLimpiar(ActionEvent event) {
        txtId.clear();
        txtTitulo.clear();
        txtIsbn.clear();
        txtPaginas.clear();
        txtAutor.clear();
        txtEditorial.clear();
        tblLibros.getSelectionModel().clearSelection();
    }

    private void mostrarAlerta(String titulo, String cabecera, String contenido) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(cabecera);
        alert.setContentText(contenido);
        alert.showAndWait();
    }
}