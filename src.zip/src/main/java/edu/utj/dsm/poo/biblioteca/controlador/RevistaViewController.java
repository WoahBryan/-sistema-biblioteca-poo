// CONTRERAS MARTINEZ BRYAN DANIEL
package edu.utj.dsm.poo.biblioteca.controlador;

import edu.utj.dsm.poo.biblioteca.modelo.Revista;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class RevistaViewController implements Initializable {

    @FXML private TextField txtId;
    @FXML private TextField txtTitulo;
    @FXML private TextField txtAnioPublicacion;
    @FXML private TextField txtVolumen;
    @FXML private TextField txtNumeroEdicion;
    @FXML private TextField txtFrecuencia;
    @FXML private CheckBox chkDisponible;

    @FXML private Button btnNuevo;
    @FXML private Button btnGuardar;
    @FXML private Button btnEditar;
    @FXML private Button btnEliminar;
    @FXML private Button btnLimpiar;

    @FXML private TableView<Revista> tblRevistas;
    @FXML private TableColumn<Revista, Integer> colId;
    @FXML private TableColumn<Revista, String> colTitulo;
    @FXML private TableColumn<Revista, Integer> colAnio;
    @FXML private TableColumn<Revista, Integer> colVolumen;
    @FXML private TableColumn<Revista, Integer> colEdicion;
    @FXML private TableColumn<Revista, String> colFrecuencia;
    @FXML private TableColumn<Revista, Boolean> colDisponible;

    private final ObservableList<Revista> listaRevistas = FXCollections.observableArrayList();
    private int siguienteId = 1;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colTitulo.setCellValueFactory(new PropertyValueFactory<>("titulo"));
        colAnio.setCellValueFactory(new PropertyValueFactory<>("anioPublicacion"));
        colVolumen.setCellValueFactory(new PropertyValueFactory<>("volumen"));
        colEdicion.setCellValueFactory(new PropertyValueFactory<>("numeroEdicion"));
        colFrecuencia.setCellValueFactory(new PropertyValueFactory<>("frecuencia"));
        colDisponible.setCellValueFactory(new PropertyValueFactory<>("disponible"));

        tblRevistas.setItems(listaRevistas);

        tblRevistas.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                txtId.setText(String.valueOf(newSel.getId()));
                txtTitulo.setText(newSel.getTitulo());
                txtAnioPublicacion.setText(String.valueOf(newSel.getAnioPublicacion()));
                txtVolumen.setText(String.valueOf(newSel.getVolumen()));
                txtNumeroEdicion.setText(String.valueOf(newSel.getNumeroEdicion()));
                txtFrecuencia.setText(newSel.getFrecuencia() != null ? newSel.getFrecuencia() : "");
                chkDisponible.setSelected(newSel.isDisponible());
            }
        });
    }

    @FXML
    private void accionNuevo(ActionEvent event) {
        accionLimpiar(event);
    }

    @FXML
    private void accionGuardar(ActionEvent event) {
        String titulo = txtTitulo.getText().trim();
        String frecuencia = txtFrecuencia.getText().trim();

        if (titulo.isEmpty() || txtAnioPublicacion.getText().trim().isEmpty()) {
            mostrarAlerta("Validación", "Campos incompletos", "El título y el año de publicación son obligatorios.");
            return;
        }

        int anio, volumen, edicion;
        try {
            anio = Integer.parseInt(txtAnioPublicacion.getText().trim());
            volumen = txtVolumen.getText().trim().isEmpty() ? 0 : Integer.parseInt(txtVolumen.getText().trim());
            edicion = txtNumeroEdicion.getText().trim().isEmpty() ? 0 : Integer.parseInt(txtNumeroEdicion.getText().trim());
        } catch (NumberFormatException e) {
            mostrarAlerta("Error", "Formato inválido", "Año, Volumen y Edición deben ser números enteros.");
            return;
        }

        if (txtId.getText().isEmpty()) {
            Revista revista = new Revista(siguienteId++, titulo, edicion);
            revista.setAnioPublicacion(anio);
            revista.setVolumen(volumen);
            revista.setFrecuencia(frecuencia);
            revista.setDisponible(chkDisponible.isSelected());
            
            listaRevistas.add(revista);
            mostrarAlerta("Éxito", "Revista registrada", "La revista ha sido guardada correctamente.");
        } else {
            Revista revista = tblRevistas.getSelectionModel().getSelectedItem();
            if (revista != null) {
                revista.setTitulo(titulo);
                revista.setAnioPublicacion(anio);
                revista.setVolumen(volumen);
                revista.setNumeroEdicion(edicion);
                revista.setFrecuencia(frecuencia);
                revista.setDisponible(chkDisponible.isSelected());
                
                tblRevistas.refresh();
                mostrarAlerta("Éxito", "Revista actualizada", "Los datos de la revista han sido modificados.");
            }
        }
        accionLimpiar(event);
    }

    @FXML
    private void accionEditar(ActionEvent event) {
        Revista revista = tblRevistas.getSelectionModel().getSelectedItem();
        if (revista == null) {
            mostrarAlerta("Aviso", "Sin selección", "Selecciona una revista de la tabla para editar.");
        } else {
            txtTitulo.requestFocus();
        }
    }

    @FXML
    private void accionEliminar(ActionEvent event) {
        Revista revista = tblRevistas.getSelectionModel().getSelectedItem();
        if (revista != null) {
            listaRevistas.remove(revista);
            accionLimpiar(event);
            mostrarAlerta("Éxito", "Revista eliminada", "El registro ha sido borrado.");
        } else {
            mostrarAlerta("Aviso", "Sin selección", "Selecciona una revista para eliminar.");
        }
    }

    @FXML
    private void accionLimpiar(ActionEvent event) {
        txtId.clear();
        txtTitulo.clear();
        txtAnioPublicacion.clear();
        txtVolumen.clear();
        txtNumeroEdicion.clear();
        txtFrecuencia.clear();
        chkDisponible.setSelected(true);
        tblRevistas.getSelectionModel().clearSelection();
    }

    private void mostrarAlerta(String titulo, String cabecera, String contenido) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(cabecera);
        alert.setContentText(contenido);
        alert.showAndWait();
    }
}