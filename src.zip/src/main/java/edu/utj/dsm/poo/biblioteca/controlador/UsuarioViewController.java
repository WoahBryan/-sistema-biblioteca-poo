// CONTRERAS MARTINEZ BRYAN DANIEL
package edu.utj.dsm.poo.biblioteca.controlador;

import edu.utj.dsm.poo.biblioteca.modelo.Usuario;
import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class UsuarioViewController implements Initializable {

    @FXML private TextField txtId;
    @FXML private TextField txtNombre;
    @FXML private TextField txtPrimerApellido;
    @FXML private TextField txtCredencial;
    @FXML private ComboBox<String> cmbEstado;
    @FXML private ImageView imgFoto;
    @FXML private Button btnSeleccionarImagen;

    @FXML private Button btnNuevo;
    @FXML private Button btnGuardar;
    @FXML private Button btnEditar;
    @FXML private Button btnEliminar;
    @FXML private Button btnLimpiar;

    @FXML private TableView<Usuario> tblUsuarios;
    @FXML private TableColumn<Usuario, Integer> colId;
    @FXML private TableColumn<Usuario, String> colNombre;
    @FXML private TableColumn<Usuario, String> colApellido;
    @FXML private TableColumn<Usuario, String> colCredencial;
    @FXML private TableColumn<Usuario, String> colEstado;

    private final ObservableList<Usuario> listaUsuarios = FXCollections.observableArrayList();
    private int siguienteId = 1;
    private String rutaImagenSeleccionada = "";

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Inicializar las columnas de la tabla
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colApellido.setCellValueFactory(new PropertyValueFactory<>("primerApellido"));
        colCredencial.setCellValueFactory(new PropertyValueFactory<>("numeroCredencial")); // Asegurate que tu modelo Usuario tenga este atributo
        colEstado.setCellValueFactory(new PropertyValueFactory<>("estado")); 

        tblUsuarios.setItems(listaUsuarios);
        
        // Agregar opciones al ComboBox de Estado (cumple con la rúbrica)
        cmbEstado.getItems().addAll("Activo", "Inactivo", "Suspendido");

        // Listener para cuando seleccionas un usuario en la tabla
        tblUsuarios.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                txtId.setText(String.valueOf(newSel.getId()));
                txtNombre.setText(newSel.getNombre());
                txtPrimerApellido.setText(newSel.getPrimerApellido());
                txtCredencial.setText(newSel.getNumeroCredencial() != null ? newSel.getNumeroCredencial() : "");
                cmbEstado.setValue(newSel.getEstado());
                
                // Cargar imagen
                rutaImagenSeleccionada = newSel.getRutaImagen();
                cargarImagenVistaPrevia(rutaImagenSeleccionada);
            }
        });
    }

    @FXML
    private void accionSeleccionarImagen(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar Fotografía del Usuario");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Archivos de Imagen", "*.png", "*.jpg", "*.jpeg"));
        Stage stage = (Stage) btnSeleccionarImagen.getScene().getWindow();
        File archivo = fileChooser.showOpenDialog(stage);
        
        if (archivo != null) {
            rutaImagenSeleccionada = archivo.toURI().toString();
            cargarImagenVistaPrevia(rutaImagenSeleccionada);
        }
    }

    private void cargarImagenVistaPrevia(String ruta) {
        if (ruta != null && !ruta.isEmpty()) {
            try {
                imgFoto.setImage(new Image(ruta));
            } catch (Exception e) {
                imgFoto.setImage(null);
            }
        } else {
            imgFoto.setImage(null);
        }
    }

    @FXML
    private void accionNuevo(ActionEvent event) {
        AccionLimpiar(event);
    }

    @FXML
    private void accionGuardar(ActionEvent event) {
        String nombre = txtNombre.getText().trim();
        String apellido = txtPrimerApellido.getText().trim();
        String credencial = txtCredencial.getText().trim();
        String estado = cmbEstado.getValue();

        if (nombre.isEmpty() || apellido.isEmpty() || credencial.isEmpty() || estado == null) {
            mostrarAlerta("Validación", "Campos incompletos", "Nombre, Apellido, Credencial y Estado son obligatorios.");
            return;
        }

        if (txtId.getText().isEmpty()) {
            Usuario usuario = new Usuario();
            usuario.setId(siguienteId++);
            usuario.setNombre(nombre);
            usuario.setPrimerApellido(apellido);
            usuario.setNumeroCredencial(credencial);
            usuario.setEstado(estado);
            usuario.setRutaImagen(rutaImagenSeleccionada);

            listaUsuarios.add(usuario);
            mostrarAlerta("Éxito", "Usuario registrado", "El usuario ha sido guardado correctamente.");
        } else {
            Usuario usuario = tblUsuarios.getSelectionModel().getSelectedItem();
            if (usuario != null) {
                usuario.setNombre(nombre);
                usuario.setPrimerApellido(apellido);
                usuario.setNumeroCredencial(credencial);
                usuario.setEstado(estado);
                usuario.setRutaImagen(rutaImagenSeleccionada);

                tblUsuarios.refresh();
                mostrarAlerta("Éxito", "Usuario actualizado", "Los datos del usuario han sido modificados.");
            }
        }
        AccionLimpiar(event);
    }

    @FXML
    private void accionEditar(ActionEvent event) {
        Usuario usuario = tblUsuarios.getSelectionModel().getSelectedItem();
        if (usuario == null) {
            mostrarAlerta("Aviso", "Sin selección", "Selecciona un usuario de la tabla para editar.");
        } else {
            txtNombre.requestFocus();
        }
    }

    @FXML
    private void accionEliminar(ActionEvent event) {
        Usuario usuario = tblUsuarios.getSelectionModel().getSelectedItem();
        if (usuario != null) {
            listaUsuarios.remove(usuario);
            AccionLimpiar(event);
            mostrarAlerta("Éxito", "Usuario eliminado", "El registro ha sido borrado.");
        } else {
            mostrarAlerta("Aviso", "Sin selección", "Selecciona un usuario para eliminar.");
        }
    }

    // Coincide con el nombre "AccionLimpiar" con A mayúscula que pusiste en tu FXML
    @FXML
    private void AccionLimpiar(ActionEvent event) {
        txtId.clear();
        txtNombre.clear();
        txtPrimerApellido.clear();
        txtCredencial.clear();
        cmbEstado.setValue(null);
        tblUsuarios.getSelectionModel().clearSelection();
        
        imgFoto.setImage(null);
        rutaImagenSeleccionada = "";
    }

    private void mostrarAlerta(String titulo, String cabecera, String contenido) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(cabecera);
        alert.setContentText(contenido);
        alert.showAndWait();
    }
}