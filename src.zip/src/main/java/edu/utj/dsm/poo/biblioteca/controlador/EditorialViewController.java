// CONTRERAS MARTINEZ BRYAN DANIEL
package edu.utj.dsm.poo.biblioteca.controlador;

import edu.utj.dsm.poo.biblioteca.modelo.Editorial;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class EditorialViewController implements Initializable {

    @FXML private TextField txtId;
    @FXML private TextField txtNombre;
    @FXML private TextField txtPais;

    @FXML private Button btnNuevo;
    @FXML private Button btnGuardar;
    @FXML private Button btnEditar;
    @FXML private Button btnEliminar;
    @FXML private Button btnLimpiar;

    @FXML private TableView<Editorial> tblEditoriales;
    @FXML private TableColumn<Editorial, Integer> colId;
    @FXML private TableColumn<Editorial, String> colNombre;
    @FXML private TableColumn<Editorial, String> colPais;

    private final ObservableList<Editorial> listaEditoriales = FXCollections.observableArrayList();
    private int siguienteId = 1;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colPais.setCellValueFactory(new PropertyValueFactory<>("pais"));

        tblEditoriales.setItems(listaEditoriales);

        tblEditoriales.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                txtId.setText(String.valueOf(newSel.getId()));
                txtNombre.setText(newSel.getNombre());
                txtPais.setText(newSel.getPais());
            }
        });
    }

    @FXML
    private void accionNuevo(ActionEvent event) {
        accionLimpiar(event);
    }

    @FXML
    private void accionGuardar(ActionEvent event) {
        String nombre = txtNombre.getText().trim();
        String pais = txtPais.getText().trim();

        if (nombre.isEmpty() || pais.isEmpty()) {
            mostrarAlerta("Validación", "Campos incompletos", "Por favor completa Nombre y País.");
            return;
        }

        if (txtId.getText().isEmpty()) {
            Editorial ed = new Editorial();
ed.setId(siguienteId++);
ed.setNombre(nombre);
ed.setPais(pais);
            listaEditoriales.add(ed);
            mostrarAlerta("Éxito", "Registro creado", "Editorial registrada correctamente.");
        } else {
            int id = Integer.parseInt(txtId.getText());
            Editorial ed = tblEditoriales.getSelectionModel().getSelectedItem();
            if (ed != null) {
                ed.setNombre(nombre);
                ed.setPais(pais);
                tblEditoriales.refresh();
                mostrarAlerta("Éxito", "Registro actualizado", "Editorial actualizada correctamente.");
            }
        }
        accionLimpiar(event);
    }

    @FXML
    private void accionEditar(ActionEvent event) {
        Editorial ed = tblEditoriales.getSelectionModel().getSelectedItem();
        if (ed == null) {
            mostrarAlerta("Aviso", "Sin selección", "Selecciona una editorial de la tabla.");
        } else {
            txtNombre.requestFocus();
        }
    }

    @FXML
    private void accionEliminar(ActionEvent event) {
        Editorial ed = tblEditoriales.getSelectionModel().getSelectedItem();
        if (ed != null) {
            listaEditoriales.remove(ed);
            accionLimpiar(event);
            mostrarAlerta("Éxito", "Eliminado", "Registro eliminado de la lista.");
        } else {
            mostrarAlerta("Aviso", "Sin selección", "Selecciona una editorial para eliminar.");
        }
    }

    @FXML
    private void accionLimpiar(ActionEvent event) {
        txtId.clear();
        txtNombre.clear();
        txtPais.clear();
        tblEditoriales.getSelectionModel().clearSelection();
    }

    private void mostrarAlerta(String titulo, String cabecera, String contenido) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(cabecera);
        alert.setContentText(contenido);
        alert.showAndWait();
    }
}