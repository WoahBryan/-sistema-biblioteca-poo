// CONTRERAS MARTINEZ BRYAN DANIEL
package edu.utj.dsm.poo.biblioteca.controlador;

import edu.utj.dsm.poo.biblioteca.modelo.Bibliotecario;
import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class BibliotecarioViewController implements Initializable {

    @FXML private TextField txtId;
    @FXML private TextField txtNombre;
    @FXML private TextField txtPrimerApellido;
    @FXML private TextField txtTurno;
    @FXML private TextField txtArea;
    @FXML private ImageView imgFoto;
    @FXML private Button btnSeleccionarImagen;

    @FXML private Button btnNuevo;
    @FXML private Button btnGuardar;
    @FXML private Button btnEditar;
    @FXML private Button btnEliminar;
    @FXML private Button btnLimpiar;

    @FXML private TableView<Bibliotecario> tblBibliotecarios;
    @FXML private TableColumn<Bibliotecario, Integer> colId;
    @FXML private TableColumn<Bibliotecario, String> colNombre;
    @FXML private TableColumn<Bibliotecario, String> colApellido;
    @FXML private TableColumn<Bibliotecario, String> colTurno;
    @FXML private TableColumn<Bibliotecario, String> colArea;

    private final ObservableList<Bibliotecario> listaBibliotecarios = FXCollections.observableArrayList();
    private int siguienteId = 1;
    private String rutaImagenSeleccionada = "";

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colApellido.setCellValueFactory(new PropertyValueFactory<>("primerApellido"));
        colTurno.setCellValueFactory(new PropertyValueFactory<>("turno"));
        colArea.setCellValueFactory(new PropertyValueFactory<>("area"));

        tblBibliotecarios.setItems(listaBibliotecarios);

        tblBibliotecarios.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                txtId.setText(String.valueOf(newSel.getId()));
                txtNombre.setText(newSel.getNombre());
                txtPrimerApellido.setText(newSel.getPrimerApellido());
                txtTurno.setText(newSel.getTurno() != null ? newSel.getTurno() : "");
                txtArea.setText(newSel.getArea() != null ? newSel.getArea() : "");
                rutaImagenSeleccionada = newSel.getRutaImagen();
                cargarImagenVistaPrevia(rutaImagenSeleccionada);
            }
        });
    }

    @FXML
    private void accionSeleccionarImagen(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Seleccionar Fotografía");
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Archivos de Imagen", "*.png", "*.jpg", "*.jpeg"));
        Stage stage = (Stage) btnSeleccionarImagen.getScene().getWindow();
        File archivo = fileChooser.showOpenDialog(stage);
        if (archivo != null) {
            rutaImagenSeleccionada = archivo.toURI().toString();
            cargarImagenVistaPrevia(rutaImagenSeleccionada);
        }
    }

    private void cargarImagenVistaPrevia(String ruta) {
        if (ruta != null && !ruta.isEmpty()) {
            try {
                imgFoto.setImage(new Image(ruta));
            } catch (Exception e) {
                imgFoto.setImage(null);
            }
        } else {
            imgFoto.setImage(null);
        }
    }

    @FXML
    private void accionNuevo(ActionEvent event) {
        accionLimpiar(event);
    }

    @FXML
    private void accionGuardar(ActionEvent event) {
        String nombre = txtNombre.getText().trim();
        String apellido = txtPrimerApellido.getText().trim();
        String turno = txtTurno.getText().trim();
        String area = txtArea.getText().trim();

        if (nombre.isEmpty() || apellido.isEmpty() || turno.isEmpty() || area.isEmpty()) {
            mostrarAlerta("Validación", "Campos incompletos", "Todos los campos son obligatorios.");
            return;
        }

        if (txtId.getText().isEmpty()) {
            Bibliotecario bibliotecario = new Bibliotecario(siguienteId++, nombre, apellido, turno, area);
            bibliotecario.setRutaImagen(rutaImagenSeleccionada);
            listaBibliotecarios.add(bibliotecario);
            mostrarAlerta("Éxito", "Bibliotecario registrado", "El empleado ha sido guardado correctamente.");
        } else {
            Bibliotecario bibliotecario = tblBibliotecarios.getSelectionModel().getSelectedItem();
            if (bibliotecario != null) {
                bibliotecario.setNombre(nombre);
                bibliotecario.setPrimerApellido(apellido);
                bibliotecario.setTurno(turno);
                bibliotecario.setArea(area);
                bibliotecario.setRutaImagen(rutaImagenSeleccionada);

                tblBibliotecarios.refresh();
                mostrarAlerta("Éxito", "Bibliotecario actualizado", "Los datos han sido modificados.");
            }
        }
        accionLimpiar(event);
    }

    @FXML
    private void accionEditar(ActionEvent event) {
        Bibliotecario bibliotecario = tblBibliotecarios.getSelectionModel().getSelectedItem();
        if (bibliotecario == null) {
            mostrarAlerta("Aviso", "Sin selección", "Selecciona un bibliotecario de la tabla para editar.");
        } else {
            txtNombre.requestFocus();
        }
    }

    @FXML
    private void accionEliminar(ActionEvent event) {
        Bibliotecario bibliotecario = tblBibliotecarios.getSelectionModel().getSelectedItem();
        if (bibliotecario != null) {
            listaBibliotecarios.remove(bibliotecario);
            accionLimpiar(event);
            mostrarAlerta("Éxito", "Bibliotecario eliminado", "El registro ha sido borrado.");
        } else {
            mostrarAlerta("Aviso", "Sin selección", "Selecciona un bibliotecario para eliminar.");
        }
    }

    @FXML
    private void accionLimpiar(ActionEvent event) {
        txtId.clear();
        txtNombre.clear();
        txtPrimerApellido.clear();
        txtTurno.clear();
        txtArea.clear();
        tblBibliotecarios.getSelectionModel().clearSelection();
        imgFoto.setImage(null);
        rutaImagenSeleccionada = "";
    }

    private void mostrarAlerta(String titulo, String cabecera, String contenido) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(cabecera);
        alert.setContentText(contenido);
        alert.showAndWait();
    }
}