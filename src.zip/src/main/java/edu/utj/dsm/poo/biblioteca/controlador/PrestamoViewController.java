// CONTRERAS MARTINEZ BRYAN DANIEL
package edu.utj.dsm.poo.biblioteca.controlador;

import edu.utj.dsm.poo.biblioteca.modelo.Prestamo;
import edu.utj.dsm.poo.biblioteca.modelo.Usuario;
import edu.utj.dsm.poo.biblioteca.modelo.Libro; // Usamos Libro como representación de Material
import java.net.URL;
import java.util.Date;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class PrestamoViewController implements Initializable {

    @FXML private TextField txtId;
    @FXML private TextField txtUsuario;
    @FXML private TextField txtMaterial;

    @FXML private Button btnNuevo;
    @FXML private Button btnGuardar;
    @FXML private Button btnEliminar;
    @FXML private Button btnLimpiar;

    @FXML private TableView<Prestamo> tblPrestamos;
    @FXML private TableColumn<Prestamo, Integer> colId;
    @FXML private TableColumn<Prestamo, String> colFecha;
    @FXML private TableColumn<Prestamo, String> colUsuario;
    @FXML private TableColumn<Prestamo, String> colMaterial;

    private final ObservableList<Prestamo> listaPrestamos = FXCollections.observableArrayList();
    private int siguienteId = 1;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Mapeo normal para ID y Fecha
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colFecha.setCellValueFactory(new PropertyValueFactory<>("fechaSalida"));
        
        // Mapeo especial para extraer atributos de objetos anidados (Usuario y Material)
        colUsuario.setCellValueFactory(cellData -> {
            Usuario u = cellData.getValue().getUsuario();
            return new SimpleStringProperty(u != null ? u.getNombre() : "Sin usuario");
        });
        
        colMaterial.setCellValueFactory(cellData -> {
            // Asumimos que Material tiene un método getTitulo() heredado en sus hijos
            return new SimpleStringProperty(cellData.getValue().getMaterial() != null ? cellData.getValue().getMaterial().getTitulo() : "Sin material");
        });

        tblPrestamos.setItems(listaPrestamos);

        tblPrestamos.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel != null) {
                txtId.setText(String.valueOf(newSel.getId()));
                txtUsuario.setText(newSel.getUsuario().getNombre());
                txtMaterial.setText(newSel.getMaterial().getTitulo());
            }
        });
    }

    @FXML
    private void accionNuevo(ActionEvent event) {
        accionLimpiar(event);
    }

    @FXML
    private void accionGuardar(ActionEvent event) {
        String nombreUsuario = txtUsuario.getText().trim();
        String tituloMaterial = txtMaterial.getText().trim();

        if (nombreUsuario.isEmpty() || tituloMaterial.isEmpty()) {
            mostrarAlerta("Validación", "Campos incompletos", "Debes ingresar el usuario y el material.");
            return;
        }

        // Como tu clase Prestamo exige objetos reales, creamos objetos "simulados" 
        // para guardar la información temporalmente en la tabla.
        Usuario usuarioTemp = new Usuario();
        usuarioTemp.setNombre(nombreUsuario);
        
        Libro materialTemp = new Libro(); 
        materialTemp.setTitulo(tituloMaterial);

        if (txtId.getText().isEmpty()) {
            // Usamos el constructor con parámetros que genera la fecha automáticamente
            Prestamo prestamo = new Prestamo(siguienteId++, usuarioTemp, materialTemp);
            
            listaPrestamos.add(prestamo);
            mostrarAlerta("Éxito", "Préstamo registrado", "El préstamo se ha guardado correctamente.");
        } else {
            Prestamo prestamo = tblPrestamos.getSelectionModel().getSelectedItem();
            if (prestamo != null) {
                prestamo.setUsuario(usuarioTemp);
                prestamo.setMaterial(materialTemp);
                // La fecha de salida no se modifica al editar según tu modelo
                
                tblPrestamos.refresh();
                mostrarAlerta("Éxito", "Préstamo actualizado", "Los datos del préstamo han sido modificados.");
            }
        }
        accionLimpiar(event);
    }

    @FXML
    private void accionEliminar(ActionEvent event) {
        Prestamo prestamo = tblPrestamos.getSelectionModel().getSelectedItem();
        if (prestamo != null) {
            listaPrestamos.remove(prestamo);
            accionLimpiar(event);
            mostrarAlerta("Éxito", "Préstamo eliminado", "El registro ha sido borrado.");
        } else {
            mostrarAlerta("Aviso", "Sin selección", "Selecciona un préstamo para eliminar.");
        }
    }

    @FXML
    private void accionLimpiar(ActionEvent event) {
        txtId.clear();
        txtUsuario.clear();
        txtMaterial.clear();
        tblPrestamos.getSelectionModel().clearSelection();
    }

    private void mostrarAlerta(String titulo, String cabecera, String contenido) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(cabecera);
        alert.setContentText(contenido);
        alert.showAndWait();
    }
}